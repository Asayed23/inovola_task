from django.shortcuts import render
from .models import coffee_machine,coffee_pod
# Create your views here.
def coffee_app(request):
    context={}
    contexts= {}
    if request.method == 'POST' :

        if request.POST.get("cm_product_type")!=' ':

            contexts=coffee_machine.objects.filter(product_type=request.POST.get("cm_product_type"))
            context.update({"result":"Result for :Coffee_machine_product_type"})
            context.update({"select": request.POST.get("cm_product_type")})
            print(contexts)
        if request.POST.get("water_line_compatible") != ' ':
            contexts=coffee_machine.objects.filter(water_line_compatible=request.POST.get("water_line_compatible"))
            context.update({"result": "Result for :Coffee_machine_water_line_compatible"})
            context.update({"select": request.POST.get("water_line_compatible")})
            print(contexts)
        if request.POST.get("cp_product_type") != ' ':
            contexts=coffee_pod.objects.filter(product_type=request.POST.get("cp_product_type"))
            print(contexts)
            context.update({"select": request.POST.get("cp_product_type")})
            context.update({"result": "Result for :Coffee_Pod_product_type"})
        if request.POST.get("coffee_flavor") != ' ':
            contexts = coffee_pod.objects.filter(coffee_flavor=request.POST.get("coffee_flavor"))
            context.update({"result": "Result for :Coffee_Pod_coffee_flavor"})
            context.update({"select": request.POST.get("coffee_flavor")})
            print(contexts)
        if request.POST.get("pack_size") != ' ':
            contexts = coffee_pod.objects.filter(pack_size=request.POST.get("pack_size"))
            context.update({"result": "Result for :Coffee_Pod_pack_size"})
            context.update({"select": request.POST.get("pack_size")})
            print(context)

        context.update({"object_list": contexts})

        print(context)


    return render(request, "coffee_app.html", context)