from django.apps import AppConfig


class CoffeeProductConfig(AppConfig):
    name = 'coffee_product'
