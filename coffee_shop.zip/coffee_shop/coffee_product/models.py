from django.db import models

# Create your models here.

class coffee_machine(models.Model):
    sku= models.CharField(blank=False, null=True, max_length=10)
    COFFEE_MACHINE_LARGE="COFFEE_MACHINE_LARGE"
    COFFEE_MACHINE_SMALL="COFFEE_MACHINE_SMALL"
    ESPRESSO_MACHINE="ESPRESSO_MACHINE"
    product_choices=[(COFFEE_MACHINE_LARGE,"COFFEE_MACHINE_LARGE"),
                     (COFFEE_MACHINE_SMALL,"COFFEE_MACHINE_SMALL"),
                     (ESPRESSO_MACHINE,"ESPRESSO_MACHINE")]

    product_type=   models.CharField(max_length=30,
                                              choices = product_choices,
                                              blank=False, null=True)

    water_line_compatible=models.CharField(max_length=30,
                                              choices = [("true","true"),("false","false")],
                                              blank=False, null=True)
    product_model= models.CharField(max_length=30,
                                              choices = [("base model","base model"),
                                                         ("premium model","premium model"),
                                                         ("deluxe model","deluxe model")],
                                              blank=False, null=True)

    def __str__(self):
        return self.sku

class coffee_pod(models.Model):
    sku = models.CharField(blank=False, null=True, max_length=10)
    COFFEE_POD_LARGE="COFFEE_POD_LARGE"
    COFFEE_POD_SMALL="COFFEE_POD_SMALL"
    ESPRESSO_POD="ESPRESSO_POD"

    product_choices= [
        (COFFEE_POD_LARGE,"COFFEE_POD_LARGE"),
        (COFFEE_POD_SMALL,"COFFEE_POD_SMALL"),
        (ESPRESSO_POD,"ESPRESSO_POD"),
        ]
    product_type = models.CharField(max_length=30,
                                    choices=product_choices,
                                    blank=False, null=True)

    COFFEE_FLAVOR_VANILLA="COFFEE_FLAVOR_VANILLA"
    COFFEE_FLAVOR_CARAMEL="COFFEE_FLAVOR_CARAMEL"
    COFFEE_FLAVOR_PSL="COFFEE_FLAVOR_PSL"
    COFFEE_FLAVOR_MOCHA="COFFEE_FLAVOR_MOCHA"
    COFFEE_FLAVOR_HAZELNUT="COFFEE_FLAVOR_HAZELNUT"


    coffee_flavor_choices=[
        (COFFEE_FLAVOR_VANILLA , "COFFEE_FLAVOR_VANILLA"),
        (COFFEE_FLAVOR_CARAMEL , "COFFEE_FLAVOR_CARAMEL"),
        (COFFEE_FLAVOR_PSL , "COFFEE_FLAVOR_PSL"),
        (COFFEE_FLAVOR_MOCHA , "COFFEE_FLAVOR_MOCHA"),
        (COFFEE_FLAVOR_HAZELNUT , "COFFEE_FLAVOR_HAZELNUT"),
        ]

    coffee_flavor=models.CharField(max_length=30,
                                    choices=coffee_flavor_choices,
                                    blank=False, null=True)





    pack_size=models.CharField(max_length=30,
                                    choices=[
                                        ("1 dozen (12)","1 dozen (12)"),
                                        ("3 dozen (36)","3 dozen (36)"),
                                        ("5 dozen (60)","5 dozen (60)"),
                                        ("7 dozen (84)","7 dozen (84)"),
                                    ],
                                    blank=False, null=True)
    def __str__(self):
        return self.sku