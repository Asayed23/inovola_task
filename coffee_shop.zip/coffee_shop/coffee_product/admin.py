from django.contrib import admin
from .models import coffee_machine,coffee_pod
# Register your models here.
admin.site.register(coffee_machine)
admin.site.register(coffee_pod)